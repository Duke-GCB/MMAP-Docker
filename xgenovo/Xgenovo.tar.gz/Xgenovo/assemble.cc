//  This test is for denovo sequencing of one sequence.
//  no backbone.


#include <iostream>
#include <sstream>
#include <vector>
#include <math.h>
#include <string>
#include <assert.h>
#include <malloc.h>

using namespace std;

#include "jvDataGenerator.h"
#include "jvState.h"
#include "jvSampler.h"
#include "jvStateSerializer.h"
#include "jvAlign.h"
#include "jvFastaParser.h"

vector<bool> success;

extern int iteration;
extern int out_of_bounds;

#define BUFFLEN 10000


int main(int argc, char ** argv)
{
    if ( (argc < 2) || (argc > 5) )
    {
        cout<<"Usage:\n";
        cout<<"- assemble <fasta_file> N alpha beta\n";        
        cout<<"will run XGenovo for N iterations with parameter alpha and beta \n\n";


        cout<<"Inputs:\n";
        cout<<"<fasta_file> is a fasta file of reads.\n";

        cout<<"Outputs:\n";
        cout<<"The output files are updated during the course of the algorithm.  It is ok to view them while the algorithm is running.  It is ok to kill the algorithm in which case the output files will represent the most updated results.\n\n";

        cout<<"Output all contigs with length > 500b to file xgenovo.fa by running:\n";
		cout<<"\tfinalize 500 xgenovo.fa <fasta_file>.dump.best\n\n"; 
        return 1;
    }
        
    string pathToDataset = string(argv[1]);
    string pathToDump0 = pathToDataset + ".dump0";
    string pathToDump2 = pathToDataset + ".dump2";
    string pathToDump1 = pathToDataset + ".dump1";
    string pathToClust = pathToDataset + ".clust";
    string pathToStatus = pathToDataset + ".status";
    string pathToBest = pathToDataset + ".dump.best";
    string pathToBestFasta = pathToDataset + ".dump.best.fa";
	

    const char *dump_str_2 = pathToDump2.c_str();
    const char *dump_str_even = pathToDump0.c_str();
    const char *dump_str_odd = pathToDump1.c_str();
    const char *dump_str_clust = pathToClust.c_str();
    const char *dump_str_best = pathToBest.c_str();
    const char *dump_str_best_fasta = pathToBestFasta.c_str();
    const char *status_str = pathToStatus.c_str();

	
    int max_iter = ( argc >= 3 ? atoi(argv[2]) : 10000 );
    int seed = 10;
    uint j = ( argc >= 6 ? atoi(argv[5]) : 0 );
    int pow_gamma = ( argc >= 4 ? atoi(argv[3]) : 35 );
	
	
    vector<jvReadData> data;
    jvState* st = NULL;
    uint width = 100;
    int endAl = 450;
    double gamma = pow(2,pow_gamma);
    double bonus = ( argc >= 5 ? (atof(argv[4])*gamma) : (0.1*gamma));
    
     

    if (argc < 6)
    {
        cout<<"Loading fasta file...\n";
        jvFastaParser::parseReadData(pathToDataset.c_str(),data);
        cout<<"Initialize an empty state...\n";
        st = new jvState(data, false, seed,true);
        cout<<"jumlah read...\n"<<data.size()<<endl;
    }
    else 
    {
        cout<<"Loading dump file "<<argv[5]<<"..."<<flush;
        st = jvStateSerializer::read(argv[5], data);
        gamma = st->getGamma();
        cout<<" Done!"<<endl;
    }

    st->setAuto();
    st->setErrorModel(0.01, 0.01);
    st->setWithInstances(false);    
    st->setGamma(gamma,bonus);
    st->setBothOrientations(true);
    st->setGeometric(true);
    jvAlign::with_cache = true;

    uint snm_count = 0;
    double best_ll = -1e100;
    bool is_gap = false;
	int p =0;

    cout<<"Running for "<<max_iter<<" iterations.\n";
    for (; j<max_iter; j++)
    {
	
    	iteration = j;
        clock_t toc, tic = clock();
        cout<<"\n----------------   Iteration "<<j<<"   ---------------------\n";
	
        jvSampler::setMAP((j+1)%100 == 0);  //every 100th iteration take the max    
        
        cout<<"Gibbs Reads...\n";
        if (j>1 && ( (j+1)%10 != 0))
            st->gibbsReads(vector<jvReadAss*>(), GIBBS_FREEZE,true);
        else
            st->gibbsReads();       
        //register from m_ins instance to seq in center 
		//gibbsread() for j=0, j=9 and multiples ...
	
	st->center();
	
	toc = clock();
        cout<<"gibbsReads done in "<<(double)(toc-tic)/CLOCKS_PER_SEC<<" seconds.\n";
	
	

        st->sampleBases();
        cout<<"sampleBases done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
        toc = clock();
  
	

        st->cleanAlignmentCache(j-11);
        cout<<"cleaning cache done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
        toc = clock();

	
        
        st->summarizeEdits();
        cout<<"sumEdit done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
        toc = clock();

	

       	st->saveStatus(status_str, iteration);
        cout<<"saving status done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
        toc = clock();
        
	

        st->freezeInstances(true);
        cout<<"freezing instances done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
        toc = clock();
            
       if ( (j+1)%10 == 0)
       	{
            if (st->ll().ll() > best_ll)
            {
                jvStateSerializer::dump(st, dump_str_best, true);
                best_ll = st->ll().ll();	
            }   	    		

        }    

	
        cout<<"saving done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
	    toc = clock();
        
	  
              
	st->sampleBases();
        st->freezeInstances(false);
	    cout<<"merge sequence...\n";


	
	if ((j>0)|| (argc == 6))
	{
	
		st->findAndAlignEnds();		
	} 
	
	cout<<"merge done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
        toc = clock();
	
	
	
     st->flipSequences();
   	   cout<<"flipSequences done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
	    toc = clock();

	

       if ((j>0) || (argc == 6))
          st->checkAllOffsets(); 
       cout<<"sampleBases and CAO done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";
	    toc = clock();
	
	
	if ( (j+1)%10 == 0)
	    jvStateSerializer::dump(st, (j % 2 ? dump_str_odd : dump_str_even),true);
        cout<<"saving done in "<<(double)(clock()-toc)/CLOCKS_PER_SEC<<" seconds.\n";

	    toc = clock();
        cout<<"Done in "<<(double)(toc-tic)/CLOCKS_PER_SEC<<" seconds.\n";
        cout<<"\n--------------------------------------------------------\n";

}
    jvSampler::release();
    delete st;
    return 0;
}

